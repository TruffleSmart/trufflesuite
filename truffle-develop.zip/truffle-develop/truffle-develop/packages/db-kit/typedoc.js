module.exports = {
  entryPoints: ["src/index.ts"],
  categorizeByGroup: false,
  readme: "none",
  plugin: ["none"],
  out: "dist/docs"
};
