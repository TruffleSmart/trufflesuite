export { DecodeAddressInputs as Inputs } from "./Inputs";
export { DecodeAddressSplash as Splash } from "./Splash";
export { DecodeAddressResult as Result } from "./Result";
