/**
 * For encoding mapping keys
 *
 * @protected
 * @category Solidity data location
 *
 * @packageDocumentation
 */

import * as Encode from "./encode";
export {
  /**
   * @protected
   */
  Encode
};
