export * from "./types"; //'export type *' is not allowed

import * as Utils from "./utils";
export { Utils };

import * as Import from "./import";
export { Import };
