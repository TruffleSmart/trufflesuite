export * from "./types"; //'export type *' is not allowed

import * as Import from "./import";
export { Import };

import * as Utils from "./utils";
export { Utils };
