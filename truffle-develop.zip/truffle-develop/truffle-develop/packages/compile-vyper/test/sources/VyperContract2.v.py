@external
@payable
def vyper_action():
    pass
