module.exports = {
  bingBam: "boom"
};
