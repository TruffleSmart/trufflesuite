module.exports = {
  abraham: "lincoln"
};
