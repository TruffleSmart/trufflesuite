This project is drizzle-box with the frontend code removed so we can test a
truffle project that uses:
 - npm installed contracts
 - uses contracts_build_directory to change build directory location
