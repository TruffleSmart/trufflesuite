declare module "@truffle/error";
