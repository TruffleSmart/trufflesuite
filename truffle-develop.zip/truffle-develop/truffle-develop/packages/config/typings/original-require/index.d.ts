declare module "original-require";
